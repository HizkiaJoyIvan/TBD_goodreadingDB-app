import React from 'react'

const TransactionTable = () => {
  return (
    <div>
      Table
    </div>
  )
}

export default TransactionTable
